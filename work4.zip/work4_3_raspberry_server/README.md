# Работа 4, пункт 3 — сервер Raspberry Pi 5

Сервер читает BME280 или BMP280 и управляет WS2812B. По умолчанию используется **SPI**:
данные ленты идут с **GPIO10, физический контакт 19**. Для схемы из методички
с **GPIO18, физический контакт 12** предусмотрен отдельный режим **PIO**.

## 1. Подключение BME280

Выключите питание перед подключением.

| BME280 | Raspberry Pi 5, физические контакты |
|---|---|
| VCC / VIN | 3.3 V — контакт 1 |
| GND | Земля — контакт 6 |
| SDA / SDI | GPIO2 / SDA — контакт 3 |
| SCL / SCK | GPIO3 / SCL — контакт 5 |

Для четырёхконтактного I2C-модуля достаточно этих соединений. На модуле с
дополнительными CS/CSB и SDO проверьте его схему: CSB должен разрешать I2C,
а SDO задаёт адрес 0x76 или 0x77. По умолчанию сервер использует 0x76;
фактический адрес проверяется ниже.

Тип датчика определяется автоматически по регистру идентификатора чипа:
**0x60 — BME280**, **0x58 — BMP280**. Оба датчика подключаются к той же шине
I2C и измеряют температуру и давление. BME280 также измеряет влажность;
BMP280 её не измеряет.

При BMP280 запрос `/humidity` возвращает `unavailable`, а обновлённое
Android-приложение озвучивает: «This sensor does not measure humidity».
Температура, давление, прогноз и управление лентой продолжают работать.
Влажность не подменяется нулём или случайным значением.

**0x58 — идентификатор чипа, а не I2C-адрес.** В параметре `--address`
используется адрес из `i2cdetect`, обычно **0x76** или **0x77**.

## 2. Подключение ленты — основной вариант SPI

| WS2812B | Подключение |
|---|---|
| DIN / DI | Сигнал GPIO10 (MOSI), физический контакт **19**, через преобразователь уровня |
| 5V / VCC | Питание ленты 5 V |
| GND | Общая земля питания ленты и Raspberry Pi |

У Raspberry Pi выходы 3.3 V, у ленты питание 5 V. Для устойчивой работы
используйте преобразователь уровня 74AHCT125 между GPIO10 и DIN, общий GND
и резистор 330–470 Ом последовательно перед DIN. Преобразователь питается
от 5 V; его /OE для используемого канала подключается к GND.
Следуйте **подписям контактов самой ленты** и подключайте именно вход DIN,
а не выход DOUT.

Ленту питают от источника 5 V с достаточным током. Общая земля обязательна;
5 V не должны попадать на GPIO Raspberry Pi. Не соединяйте положительные
выходы двух независимых источников питания. В сервере по умолчанию 8
светодиодов и яркость 0.1; количество можно изменить параметром `--pixels`.

**В режиме SPI лента не подключается к GPIO18.** Интерфейс SPI0 используется
лентой целиком; другие SPI-устройства к той же шине в этой схеме не подключайте.
BME280 использует отдельную шину I2C.

## 3. Настройка Raspberry Pi OS

Все команды ниже выполняются в терминале **Raspberry Pi**, а не в Windows.
Скопируйте эту папку на Raspberry Pi в домашнюю директорию, например
`~/work4_3_raspberry_server`.

Включите интерфейсы:

```bash
sudo raspi-config
```

Выберите **Interface Options → I2C → Enable** и **SPI → Enable**, затем
перезагрузите Raspberry Pi. Отключать аудио для SPI не требуется.

Установите инструменты и дайте обычному пользователю доступ к шинам:

```bash
sudo apt update
sudo apt install -y python3-venv python3-dev python3-lgpio i2c-tools
sudo usermod -aG i2c,spi,gpio "$USER"
```

После изменения групп выйдите из сеанса и войдите снова либо перезагрузитесь.
Затем проверьте датчик и SPI:

```bash
i2cdetect -y 1
ls -l /dev/i2c-1 /dev/spidev0.0
```

В таблице `i2cdetect` должен появиться `76` или `77`. Если адрес не найден,
проверьте питание 3.3 V, землю, SDA и SCL.

Создайте отдельное окружение внутри папки сервера:

```bash
cd ~/work4_3_raspberry_server
python3 -m venv --system-site-packages .venv
.venv/bin/python -m pip install --upgrade pip
.venv/bin/python -m pip install -r requirements.txt
```

`python3-lgpio` устанавливает готовый драйвер из репозитория Raspberry Pi OS.
Флаг `--system-site-packages` позволяет окружению `.venv` использовать этот
драйвер, вместо попытки собрать `lgpio` из исходников через pip.

До запуска сервера проверьте аппаратные библиотеки тем же Python:

```bash
.venv/bin/python -c "import lgpio, board, neopixel_spi, adafruit_bmp280; from adafruit_bme280 import basic; print('Hardware libraries OK')"
```

Если установка завершилась ошибкой `Failed to build installable wheels ...
lgpio`, а сервер пишет `No module named 'board'`, выполните восстановление
из уже скопированной папки сервера:

```bash
sudo apt update
sudo apt install -y python3-lgpio python3-venv python3-dev
python3 -m venv --system-site-packages .venv
.venv/bin/python -c "import lgpio; print(lgpio.__file__)"
.venv/bin/python -m pip install --upgrade pip setuptools wheel
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python -c "import board, neopixel_spi, adafruit_bmp280; from adafruit_bme280 import basic; print('Hardware libraries OK')"
```

Повторная команда `venv` включает доступ к системным пакетам в существующем
окружении; удалять `.venv` не нужно. Если любой шаг заканчивается ошибкой,
остановитесь на нём и сохраните полный текст ошибки. Для поиска причины
сбоя сборки нужны строки перед финальным `Failed to build`, а также версии
`python3 --version` и `.venv/bin/python --version`.

Модуль `board` входит в **Adafruit-Blinka**. Отдельный пакет `board` через
pip устанавливать не нужно. Установка и запуск выполняются одним и тем же
интерпретатором `.venv/bin/python`; запуск через другой Python или Thonny
может снова дать `No module named 'board'`.

## 4. Запуск сервера через SPI

```bash
cd ~/work4_3_raspberry_server
.venv/bin/python server.py --led-backend spi --address 0x76 --pixels 8
```

Если датчик найден по адресу 77, используйте `--address 0x77`. Если на ленте
другое число светодиодов, измените `--pixels`. RGB-лента WS2812B использует
порядок каналов GRB, он уже указан в коде.

Адрес `0.0.0.0` означает прослушивание всех сетевых интерфейсов Raspberry Pi.
В телефоне нужно указать настоящий IP из:

```bash
hostname -I
```

Например, `http://192.168.1.100:8000/`. Сервер должен работать весь показ.
Остановка — **Ctrl+C**; при обычной остановке лента гаснет.

Порт 8000 не требует root. SPI/I2C доступны пользователю из соответствующих
групп; входить в графическую среду под root для этого варианта не требуется.

## 5. GPIO18 как в методичке — вариант PIO для Pi 5

Этот вариант сохраняет DIN на **GPIO18, физическом контакте 12** и использует
библиотеку `Adafruit-Blinka-Raspberry-Pi5-Neopixel`.
Питание, земля и преобразователь уровня подключаются так же, как выше;
меняется только GPIO сигнала.

Сначала проверьте наличие устройства:

```bash
ls -l /dev/pio0
```

Если устройства нет, используйте основной SPI-вариант с DIN на контакте 19
либо настройте поддержку PIO по
[инструкции Adafruit для Raspberry Pi 5](https://learn.adafruit.com/circuitpython-on-raspberrypi-linux/using-neopixels-on-the-pi-5).
Поддержка PIO зависит от ядра и прошивки; сервер не обновляет их автоматически.
Старая библиотека `rpi_ws281x` и обычный `neopixel.NeoPixel(board.D18, ...)`
из примера методички не являются взаимозаменяемой настройкой для Pi 5.

Установите дополнительные зависимости:

```bash
cd ~/work4_3_raspberry_server
.venv/bin/python -m pip install -r requirements-pio.txt
```

Если `/dev/pio0` принадлежит группе root, создайте правило доступа:

```bash
echo 'SUBSYSTEM=="*-pio", GROUP="gpio", MODE="0660"' | sudo tee /etc/udev/rules.d/99-voicehome-pio.rules
sudo udevadm control --reload-rules
sudo udevadm trigger
```

После перезагрузки проверьте, что пользователь входит в `gpio`, а группа
устройства — `gpio`. Запустите:

```bash
.venv/bin/python server.py --led-backend pio --address 0x76 --pixels 8
```

### Повторный запуск на настроенной Raspberry Pi

На проверенной установке проект находится в
`~/Downloads/hse-arduino-main/work4_3_raspberry_server`, лента подключена к
GPIO18 (физический контакт 12), а адрес BME280 — 0x76. После перезагрузки
выполните в терминале Raspberry Pi:

```bash
cd ~/Downloads/hse-arduino-main/work4_3_raspberry_server
.venv/bin/python server.py --led-backend pio --address 0x76 --pixels 8
```

Терминал должен оставаться открытым. Остановка — Ctrl+C. Автозапуск не
настроен; зависимости и окружение `.venv` сохраняются после перезагрузки,
переустанавливать их не нужно.

Проверьте адрес командой `hostname -I`. При настройке использовался
`http://10.167.32.100:8000/`; если IP изменился, обновите адрес на телефоне.

Исправление HTTP-соединения не требует изменений Android-приложения. Один раз
закройте его из списка недавних приложений и откройте снова, чтобы очистить
старое соединение. После обычных перезагрузок Raspberry Pi достаточно
запустить сервер. При переходе на версию с поддержкой BMP280 обновите
приложение через Run в Android Studio: новая версия корректно озвучивает
отсутствие измерения влажности.

### Обновление для BMP280

Обновите файлы проекта из GitHub. Если проект был скачан архивом, скопируйте
новые `server.py`, `hardware.py` и `requirements.txt` в прежнюю папку сервера,
сохранив существующее окружение `.venv`. Затем в этой папке выполните:

```bash
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python server.py --led-backend pio --address 0x76 --pixels 8
```

Перед запуском обновлённого сервера остановите прежний. Команда выше относится
к ленте на GPIO18; для ленты на GPIO10 используется `--led-backend spi`.
В журнале запуска появится `Detected BMP280` или `Detected BME280`.

## 6. Проверка HTTP

На Raspberry Pi можно использовать curl, с телефона — браузер:

```bash
curl http://127.0.0.1:8000/health
curl http://127.0.0.1:8000/temperature
curl http://127.0.0.1:8000/pressure
curl http://127.0.0.1:8000/humidity
curl http://127.0.0.1:8000/weather
curl http://127.0.0.1:8000/FF0000
curl http://127.0.0.1:8000/random
curl http://127.0.0.1:8000/000000
```

| Путь | Ответ |
|---|---|
| /temperature | Температура, округлённая до целых °C |
| /pressure | Давление, округлённое до целых мм рт. ст. |
| /humidity | Влажность BME280 в целых %; для BMP280 — `unavailable` |
| /weather | Английская фраза учебного прогноза |
| /RRGGBB | Установленный цвет в HEX |
| /random | Фактически выбранный случайный цвет в HEX |
| /health | Доступность сервера и режим: real hardware / DEMO |

Также поддерживается формат из объяснения методички:
`http://IP:8000/?params=temperature`. Неизвестная команда даёт HTTP 404,
ошибка чтения датчика или управления лентой — HTTP 503. Для BMP280 отсутствие
влажности не считается ошибкой; ответ содержит `unavailable`. Тестовый режим не включается автоматически
при ошибке оборудования.

Сервер явно передаёт заголовок `Connection: close`: после ответа HTTP/1.0
соединение закрывается. Это важно для OkHttp 3.6.0 из методички. Без заголовка
эта версия клиента может повторно использовать уже закрытый сокет, и тогда
успешные запросы чередуются с `unexpected end of stream`. Если используется
старая копия `server.py`, обновите файл и перезапустите сервер.

Драйверы BME280 и BMP280 возвращают давление в **hPa**. Для ответа `/pressure` оно
переводится в мм рт. ст., а для `/weather` сравнивается с 1022.69 и 1009.14 hPa
из методички. Это учебное правило по одному измерению.

## 7. Проверка без схемы

Этот режим работает на Windows/Linux без аппаратных библиотек:

```bash
python server.py --demo
```

В журнале и `/health` явно указано **DEMO**. Значения фиксированы: 23 °C,
760 мм рт. ст., 45 %. Лента физически не управляется. Для защиты сервер
запускается **без `--demo`**, с реальным BME280 и лентой.

Тесты HTTP-сервера:

```bash
python -m unittest discover -s tests -v
```

## Источники настройки Pi 5

- [NeoPixel на Pi 5: PIO и SPI](https://learn.adafruit.com/circuitpython-on-raspberrypi-linux/using-neopixels-on-the-pi-5)
- [API NeoPixel SPI](https://docs.circuitpython.org/projects/neopixel_spi/en/latest/api.html)
- [API BME280 и единицы давления](https://docs.circuitpython.org/projects/bme280/en/latest/api.html)
- [API BMP280](https://docs.circuitpython.org/projects/bmp280/en/latest/api.html)
- [Подключение и преобразование уровня](https://learn.adafruit.com/neopixels-on-raspberry-pi/raspberry-pi-wiring)
- [Готовый lgpio для Raspberry Pi OS](https://github.com/adafruit/lgpio-python-wheels#alternative-apt-raspberry-pi-os-only)
